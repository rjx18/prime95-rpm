/* Common definitions in Prime95 and NTPrime */

void getWindowsSerialNumber (char *);
void getWindowsSID (char *);
void getWindowsSerialNumber_2 (char *);
void getWindowsSID_2 (char *);

